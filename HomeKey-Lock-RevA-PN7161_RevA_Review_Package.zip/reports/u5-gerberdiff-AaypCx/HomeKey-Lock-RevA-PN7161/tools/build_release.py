#!/usr/bin/env python3
"""Run all Rev A checks and create reproducible JLC/review archives."""

from __future__ import annotations

import hashlib
import subprocess
import sys
import zipfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
PRODUCTION = ROOT / "production"
GERBERS = PRODUCTION / "gerbers"
REPORTS = ROOT / "reports"
PROJECT = "HomeKey-Lock-RevA-PN7161"


def run(script):
    subprocess.run([sys.executable, str(HERE / script)], cwd=ROOT, check=True)


def zip_paths(output, paths, base):
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(paths):
            if path.is_file():
                archive.write(path, path.relative_to(base))


def main():
    run("audit_board.py")
    run("audit_connectivity.py")
    run("export_manufacturing.py")
    run("render_board.py")
    run("audit_manufacturing.py")

    fab_zip = PRODUCTION / f"{PROJECT}_JLCPCB_Gerber.zip"
    zip_paths(fab_zip, GERBERS.iterdir(), GERBERS)

    review_zip = PRODUCTION / f"{PROJECT}_RevA_Review_Package.zip"
    included = []
    for directory in (ROOT / "kicad", ROOT / "docs", ROOT / "design", ROOT / "firmware", ROOT / "reports", ROOT / "production" / "assembly", ROOT / "tools"):
        included.extend(path for path in directory.rglob("*") if path.is_file() and "__pycache__" not in path.parts)
    included.extend([ROOT / "README.md", PRODUCTION / "JLCPCB_ORDER_NOTES.md", fab_zip])
    zip_paths(review_zip, included, ROOT)

    checksum_path = PRODUCTION / "CHECKSUMS.sha256"
    release_files = sorted([fab_zip, review_zip, *GERBERS.iterdir(), *(PRODUCTION / "assembly").iterdir()])
    lines = []
    for path in release_files:
        if path.is_file():
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            lines.append(f"{digest}  {path.relative_to(PRODUCTION)}")
    checksum_path.write_text("\n".join(lines) + "\n", encoding="ascii")
    print(f"Created {fab_zip.relative_to(ROOT)}")
    print(f"Created {review_zip.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
